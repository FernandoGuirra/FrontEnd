var botaoAdicionar = document.querySelector("#buscar-pacientes");
botaoAdicionar.addEventListener("click", function(){
	//console.log("Buscando pacientes");

	var xhr = new XMLHttpRequest();

	xhr.open("GET", "http://api-pacientes.herokuapp.com/pacientes"); //funcao que abre a conexao com o endereço que queremos fazer, especificando o tipo de requisição (no nosso caso, do tipo get)

	xhr.addEventListener("load", function (){
		var erroAjax = document.querySelector("#erro-ajax");
		if (xhr.status == 200) { // status é para informar o retorno que a página deu verificando algum erro. O erro 200 informar que a aquisição deu tudo certo
			erroAjax.classList.add("invisivel");
			var resposta = xhr.responseText;
			//console.log(typeof resposta);
			var pacientes = JSON.parse(resposta); // como o site (resposta) é um objeto json, então a funcao parser do JSON vai ler essa variavel e devolver como um objeto javaScript
			//console.log(pacientes);
			//console.log(typeof pacientes);

			pacientes.forEach(function(paciente){
				adicionaPacienteNaTabela(paciente);
			});

		} else {
			console.log(xhr.status);
			console.log(xhr.response);
			erroAjax.classList.remove("invisivel");
		}

	}); // adicionando um evento de, quando o conteudo de acesso for carregado então executa uma função para mim
	
	xhr.send(); //pega nossa requisição e envia ela, acessando o endereço

});