/* Uma boa prática de programação é ter arquivo separado para diferentes linguagens de programação da pagina web.
Uma para html, um para css e agora um arquivo somente para codigo do tipo javaScript. É sempre uma boa prática fazer a separação de mundos. */

/*console.log("Fui carregado de um arquivo externo");*/

var titulo = document.querySelector(".titulo-principal");

titulo.textContent = "Aparecida Nutricionista";

// BUSCANOO PESO DO DOCUMENT
/*definir um id em paciente pois todos possui a mesma classe. Para encontrar o id basta inser #nomeid */
/*var paciente = document.querySelectorAll("#primeiro-paciente"); 

/* var pacientes = document.querySelector(".paciente");
console.log(pacientes); //querySelector só tem a capacidadede trazer um unico elemento. Se ao invés disso estiver interessado em trazer vários elementos que tem uma classe devemos usar a funçãõ querySelectorAll que retorna uma lista com todos pacientes com a classe desejada
*/

// CRIANDO LOOP
var pacientes = document.querySelectorAll(".paciente"); // um array com todos os pacientes com a classe paciente
//console.log(pacientes);

for (var i = 0; i < pacientes.length; i++) {
	var paciente = pacientes[i];
	/* agora precisamos buscar dentro do primeiro paciente os dados que estamos interesssados, nesse caso altura e peso que são uma td. 
	Para isso basta usar a função querySelector para buscar dentro de paciente agora */
	var tdpeso = paciente.querySelector(".info-peso");

	var peso = tdpeso.textContent; //passando para variavel peso o conteudo de texto de tdpeso

	// BUSCANOO ALTURA DO DOCUMENT
	var tdaltura = paciente.querySelector(".info-altura");
	var altura = tdaltura.textContent;

	var tdimc = paciente.querySelector(".info-imc"); //acessando td imc

	/*
	var pesoEValido = true;
	var alturaEValido = true;

	if (peso <= 0 || peso >= 600) {
		//alert("Peso inválido \n \nConfira e insira novamente");
		pesoEValido = false;
		tdimc.textContent = "Peso Inválido";
		//paciente.style.background = "ligthcoral"; // propriedade que modifica os estilos das variaveis do html. No nosso caso queremos pintar toda linha em pacientes
		// ou paciente.style.color = "red"; que altera a cor da fonte, para auxiliar na visualização do usuario quanto ao erro
		// ou paciente.style.backgroundColor = "ligthcoral";
		paciente.classList.add("paciente-invalido");
	}*/

	var pesoEValido = validaPeso(peso);
	// ! é  negação - ou seja, só vai entrar se a negação for satisfeita se o peso nao for true
	if (!pesoEValido) {
		tdimc.textContent = "Peso Inválido";
		paciente.classList.add("paciente-invalido");
	}

	var alturaEValido = validaAltura(altura);
	if (!alturaEValido) {
		tdimc.textContent = "Altura Inválido";
		paciente.classList.add("paciente-invalido");
	}

	/* testes de exibição
	console.log(paciente); // conter o tr
	console.log(tdpeso); //conter somente td peso
	console.log(peso); // texto com o peso
	console.log(altura);
	*/

	//ou if (pesoEValido && alturaEValido)
	if (pesoEValido && alturaEValido){
		/*var imc = peso/(altura * altura);*/
		//console.log(imc); //teste
		//tdimc.textContent = imc; //trocando informação contida para o cálculo realizado
		var imc = calculaImc(peso, altura);
		//tdimc.textContent = imc.toFixed(2); // funcao tofixed(numCasas) escolhe a quantidade de casas decimais que o numero deve ter
		tdimc.textContent = imc;
	} else if (pesoEValido==false && alturaEValido==false) {
		tdimc.textContent = "Peso e Altura Inválidos";
	}
}

//Quebrando o codigo em funcoes
function calculaImc(peso, altura) {
	var imc = 0;
	imc = peso/(altura * altura);
	return imc.toFixed(2);
}

// funcao para validar value do paciente inserido e da tabela
function validaPeso(peso){
	if (peso >= 0 && peso <= 600) {
		return true;
	}else {
		return false;
	}
}

function validaAltura(altura) {
	if (altura >= 0 && altura <= 3.00){
		return true;
	} else {
		return false;
	}
}