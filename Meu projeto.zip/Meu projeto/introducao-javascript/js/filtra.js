var campoFiltro = document.querySelector("#filtrar-tabela");

// vamos passar um evento de escutar ao campo input para que toda vez que o usuário começar a digitar ele apresente nomes relacionados
// cada letra inputada ele chamará a função. Queremos ter acesso ao .value do campo filtro
campoFiltro.addEventListener("input", function (){
	//console.log("Digitaram no campo");
	//campoFiltro.value; //ou this.value pois nele que está atrelado o evento

	// precisamos pegar todos os nomes dos pacientes da tabela para comparar com o que for inserido
	var pacientes = document.querySelectorAll(".paciente");

	// devemos passar por todo array de paciente para comparar com a string inserida no campo input
	// se for diferente do que está escrito, some, e se for igual, mostra

	if ( this.value.length > 0 ){
		for (var i = 0; i < pacientes.length; i++) {
			var paciente = pacientes[i];
			var tdNome = paciente.querySelector(".info-nome");
			var nome = tdNome.textContent;
			var expressao = new RegExp(this.value, "i"); // expressão regular onde voce infomar, no primeiro parâmetro, o que quer que ela busque e, no segundo, como quer que ela busque
			// case ensest que liga se o que tá procurando é maiuscula ou minuscula, ou case insenst que não liga
			// RegExp(this.value, case) -> this.value é o que ela busca que é referente ao conteudo de texto do campo input; case = "i", não liga se é maiuscula ou minuscula
			if( !expressao.test(nome) ){ // testar se no nome tem pelo menos algum pedaço da expressão
				paciente.classList.add("invisivel");
			} else {
				paciente.classList.remove("invisivel");
			}
		}
	} else { // remover a classe para que todos os elementos voltem a ser mostrados quando o input estiver vazio
		for (var i = 0; i < pacientes.length; i++) {
			var paciente = pacientes[i];
			paciente.classList.remove("invisivel");
		}
	}
})