// esse arquivo vai ter a logica de receber todos os paciente e quando efetuar um clique duplo do mouse em cima do paciente ele será excluído
var pacientes = document.querySelectorAll(".paciente");

/* onde for clicado na tabela, o evento vai subindo até tbody, em qualquer parte que o clique acontecer da tabela
// em vez de colocar um evento para cada elemento da tabela, basta inserir um evento no pai onde todos os seus filhos, quando forem clicados, vão submeter a eles
var tabela = document.querySelector("#tabela-pacientes");

tabela.addEventListener("click", function) {
	console.log("Fui clicado");
}*/

/* da problema pois para cada elemento deve ser criado um evento desse tipo

pacientes.forEach(function(paciente){
	paciente.addEventListener("dblclick", function(){
		//console.log("Fui clicado com um duplo clique"); teste pois agora queremos remover
		// A funcao que faz a remoção de um elemento da página, através da .remove() presente em elementos capturados pela querySelector
		// A propriedade this tem a ver com quem sofreu determinada ação, quem o evento está atrelado
		this.remove();// O paciente que está escutando o evento e remove
	}); //vamos escutar um evento de duplo clique em cada tr
});*/

var tabela = document.querySelector("table");

tabela.addEventListener("dblclick", function(evento) {
	// event vai informar qual filho foi clicado ao inves da propriedade this que está atrelada ao evento por completo 
	// event através da propriedade target, event.target, vai retornar quem foi o alvo do clique
	//event.target.remove(); // não vai da certo pois só irá remover onde está sendo clicado
	var alvoEvento = event.target;
	var paiDoAlvo = alvoEvento.parentNode; //tr referente ao paciente que queremos remover, ou seja, quem é o pai de onde está sendo clicado? essa é a pergunta que faz
	paiDoAlvo.classList.add("fadeOut");

	setTimeout( function (){ // fala para o navegador segurar um pouco sua ação para que depois de um tempo especificado ele vai executar a demais linhas que quer fazer esperar. Dessa forma é possível ver a ação
		paiDoAlvo.remove();// agora vai remover a linha inteira da tabela
	}, 500); // ou seja, funcao setTimeout, espera a funcao remove() e depois de 500ms executa ela
});