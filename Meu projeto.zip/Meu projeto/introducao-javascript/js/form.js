// Aqui nesse arquivo vai todo codigo relacionado ao form


/* Aprendendo a escutar determinado eventos no JS
// funcao para escutar o evento do usuario na página
// a funcao addEventListener que adiciona um escutador de evento onde recebe como parametro o evento que se espera do usuario
titulo.addEventListener("click", mostraMensagem); //escuta evento do tipo click
// dessa forma a funcao addEventListener vai chamar a funcao mostra mensagem quando o usuario interagir clicando na tag da classe titulo

function mostraMensagem() {
	alert("Olá, me chamou?")
}

/* também poderia ser feito através de funcão anonima que é declarado internamente, só existe nesse contexto
titulo.addEventListener("click", function(){
	alert("Olá, posso ajudar medindo seu imc?");
});
*/

//Vamos buscar o botão adicionar no final do formulário
var botaoAdicionar = document.querySelector("#adicionar-paciente");

botaoAdicionar.addEventListener("click", function(event){
	event.preventDefault(); // funcao que define um comportamento padrão recebendo como parametro o event, o cara responsável por controlar o evento
	// Assim vai prevenir os comportamentos padrão da página que seria enviar o formulário (apagar informações) e atualizar página
	//alert("Usuário adicionado"); só para teste
	var form = document.querySelector("#form-adiciona"); // criando acesso ao formulário através do id, onde tem acesso a todos os names do input na form
	/*console.log(form.altura); //acesso ao name altura
	console.log(form.altura.value); // acesso ao conteudo do name altura*/
	// Quando seleciona um form consegue ter acesso aos input do form através da propriedade name do input
	// Através da propriedade value é possível resgatar só o valor de cada input
	/* Vamos transformar essa parte do código em funcao
	// Essa parte está extraindo informações do paciente do form
	var nome = form.nome.value;
	var peso = form.peso.value;
	var altura = form.altura.value;
	var gordura = form.gordura.value;
	/* Teste de funcionamento
	console.log(nome);
	console.log(peso);
	console.log(altura);
	console.log(gordura); */
	var paciente = obtemPacienteDoFormulario(form);
	//console.log(paciente); representa um objeto com os dados dos pacientes

	//Vamos usar a funcao createElement para criar um novo elemento, no nosso caso, uma nova linha na tabela html dentro do javascript
	// um paciente nada mais é que uma tr com vários tds dentro, cada um com seus dados
	/* Vamos transformar essa parte do código em funcao
	// Cria a tr e a td do paciente
	var pacienteTr = document.createElement("tr");
	// o document é especificando onde queremos criar o elemento, e entre parenteses estamos especificando o que queremos criar
	// Além de criar a tr agora vamos criar as outras tds
	var nomeTd = document.createElement("td");
	var pesoTd = document.createElement("td");
	var alturaTd = document.createElement("td");
	var gorduraTd = document.createElement("td");
	var imcTd = document.createElement("td");
	
	// vamos resgatar o conteudo extraído do formulário
	nomeTd.textContent = nome;
	pesoTd.textContent = peso;
	alturaTd.textContent = altura;
	gorduraTd.textContent = gordura;

	// Calculando imc quando a pessoa inserir - FERNANDO
	imcTd.textContent = calculaImc(peso, altura);


	// dessa maneira, os elementos tr e tds são indepedentes, não tem dependencia ou ordem entre eles. Primeiro, temos que inserir todas tds dentro da tr
	// Isso é feito através da funcao appendChild que, como o proprio nome diz, vai colocar como filho os parametros passados. Todos os tds são filho do tr. Então, vamos fazer isso
	pacienteTr.appendChild(nomeTd);
	pacienteTr.appendChild(pesoTd);
	pacienteTr.appendChild(alturaTd);
	pacienteTr.appendChild(gorduraTd);
	pacienteTr.appendChild(imcTd); // inserir o campo de imc também*/

	//var pacienteTr = montaTr(paciente);
	// agora precisamos inserir ela na tabela. A função appendChild foi usada para colocar cada td na tr. O que vamos fazer é utilizar a função appendChild para coloar o tr dentro do tbody
	// Para isso, precisamos resgatar  o tbody para ter acesso a tabela
	// adicionando paciente na tabela

	var erros = validaPaciente(paciente);
	console.log(erros);
	if (erros.length > 0){
		exibeMensagensDeErro(erros);
		return; //sai da funcao sem chegar na parte que adiciona na tabela, logo abaixo
	}

	//var tabela = document.querySelector("#tabela-pacientes");

	// vamos adicionar agora o tr como filho da tabela, inserindo assim o novo paciente do formulário
	//tabela.appendChild(pacienteTr); 

	adicionaPacienteNaTabela(paciente);

	form.reset(); // funcao do form para limpar os campos toda vez que o paciente for adicionado

	var mensagensErro = document.querySelector("#mensagens-erro");
	mensagensErro.innerHTML="";
});

// FUNCOES

function adicionaPacienteNaTabela (paciente) {
	var pacienteTr = montaTr(paciente);
	var tabela = document.querySelector("#tabela-pacientes");
	tabela.appendChild(pacienteTr); 
}

function obtemPacienteDoFormulario(form) {
	// Objeto é um representação do mundo real, ou da programação, que tem caracteristicas em comum
	//nome,peso,altura,gordura são caracteristica de um mesmo paciente, então poderia ser representado por uma mesma coisa. Isso seria um objeto
	// objeto é criado através das chaves onde dentro é passado as propriedades do objeto, as caracteristicas, :valor
	var paciente = {
		nome: form.nome.value,
		peso: form.peso.value,
		altura: form.altura.value,
		gordura: form.gordura.value,
		imc: calculaImc(form.peso.value, form.altura.value)
	}
	/*
	var nome = form.nome.value;
	var peso = form.peso.value;
	var altura = form.altura.value;
	var gordura = form.gordura.value;*/

	return paciente; //vai ser um array com as propriedades
}

function montaTr(paciente) {
	var pacienteTr = document.createElement("tr");
	pacienteTr.classList.add("paciente");

	/* como é comum, o trecho de codigo, para todos elementos vamos tranformá-lo em funcao 
	var nomeTd = document.createElement("td");
	nomeTd.ClassList.add("info-nome");
	var pesoTd = document.createElement("td");
	pesoTd.ClassList.add("info-peso");
	var alturaTd = document.createElement("td");
	var gorduraTd = document.createElement("td");
	var imcTd = document.createElement("td");
	
	nomeTd.textContent = paciente.nome;
	pesoTd.textContent = paciente.peso;
	alturaTd.textContent = paciente.altura;
	gorduraTd.textContent = paciente.gordura;
	imcTd.textContent = paciente.imc; */

	/* ou pode ser conforme o codigo abaixo não comentado - para enxugar ainda mais o codigo
	var nomeTd = montaTd(paciente.nome, "info-nome");
	var pesoTd = montaTd(paciente.peso, "info-peso");
	var alturaTd = montaTd(paciente.altura, "info-altura");
	var gorduraTd = montaTd(paciente.gordura, "info-gordura");
	var imcTd = montaTd(paciente.imc, "info-imc");	

	pacienteTr.appendChild(nomeTd);
	pacienteTr.appendChild(pesoTd);
	pacienteTr.appendChild(alturaTd);
	pacienteTr.appendChild(gorduraTd);
	pacienteTr.appendChild(imcTd); */

	// para enxugar mais ainda o codigo
	pacienteTr.appendChild(montaTd(paciente.nome, "info-nome"));
	pacienteTr.appendChild(montaTd(paciente.peso, "info-peso"));
	pacienteTr.appendChild(montaTd(paciente.altura, "info-altura"));
	pacienteTr.appendChild(montaTd(paciente.gordura, "info-gordura"));
	pacienteTr.appendChild(montaTd(paciente.imc, "info-imc"));

	return pacienteTr;
}

function montaTd(dado,classe) {
	var td = document.createElement("td");
	td.textContent = dado;
	td.classList.add(classe);
	return td;
}

function validaPaciente(paciente){

	var erros = [];
	
	if(paciente.nome.length == 0){
		erros.push("Nome Inválido");
	}

	if (!validaPeso(paciente.peso) || paciente.peso.length == 0) { // && validaAltura(paciente.altura)
		erros.push("Peso Inválido");
	}
	// ou, por ser um if de uma linha: if (!validaPeso(paciente.peso)) validaAltura(paciente.altura);

	if(!validaAltura(paciente.altura) || paciente.altura.length == 0) {
		erros.push("Altura Inválida");
	}

	/*if (paciente.altura.length == 0) {
		erros.push("Altura em Branco");
	}*/

	if (paciente.gordura.length == 0) {
		erros.push("Gordura Inválida");
	}

	return erros;
}

function exibeMensagensDeErro(erros){
	var ul = document.querySelector("#mensagens-erro");
	ul.innerHTML=""; // para apagar as mensagens de erro que foram inseridas. InnerHtml permite controlar o html de determinado item

	// forEach é um processo iterativo semelhante ao for mas que já sabe o passo iterativo
	erros.forEach(function(erro){
		var li = document.createElement("li");
		li.textContent = erro;
		ul.appendChild(li);
	});
}